import { createFileRoute, Link } from "@tanstack/react-router";
import { useRef, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { AnimatePresence, motion } from "framer-motion";
import { Bookmark, Clapperboard, Grid3x3, Heart, Loader2, MessageCircle, Play, X } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth, type Profile } from "@/lib/auth";
import { fetchPosts, POST_SELECT, type FeedPost } from "@/lib/queries";
import { uploadMedia } from "@/lib/media";
import { Avatar } from "@/components/Avatar";
import { cn } from "@/lib/utils";
import { FollowButton, FollowCounts, VerificationRequest, VerifiedBadge } from "@/components/SocialIdentity";
import { Button } from "@/components/ui/button";
import { MediaLightbox } from "@/components/MediaLightbox";

export const Route = createFileRoute("/_authenticated/u/$username")({
  head: ({ params }) => ({ meta: [{ title: `@${params.username} — Talkigram` }, { name: "description", content: `${params.username}'s profile on Talkigram.` }, { property: "og:title", content: `@${params.username} — Talkigram` }, { property: "og:description", content: `${params.username}'s profile on Talkigram.` }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: ProfilePage,
});

function ProfilePage() {
  const { username } = Route.useParams();
  const { userId } = useAuth();
  const [tab, setTab] = useState<"posts" | "reels" | "saved">("posts");
  const [editing, setEditing] = useState(false);
  const [preview, setPreview] = useState<FeedPost | null>(null);

  const { data: profile, isLoading } = useQuery({
    queryKey: ["profile", username],
    queryFn: async () => (await supabase.from("profiles").select("*").eq("username", username).maybeSingle()).data,
  });
  const { data: posts = [] } = useQuery({
    queryKey: ["posts", "user", profile?.id], enabled: !!profile, queryFn: () => fetchPosts({ userId: profile!.id, limit: 200 }),
  });
  const isMe = profile?.id === userId;
  const { data: saved = [] } = useQuery({
    queryKey: ["saves", "posts", userId], enabled: isMe && tab === "saved",
    queryFn: async () => {
      const ids = (await supabase.from("saves").select("post_id").eq("user_id", userId!)).data?.map((s) => s.post_id) ?? [];
      if (!ids.length) return [];
      return ((await supabase.from("posts").select(POST_SELECT).in("id", ids)).data ?? []) as unknown as FeedPost[];
    },
  });

  if (isLoading) return <div className="flex justify-center py-20"><Loader2 className="h-6 w-6 animate-spin text-cyan" /></div>;
  if (!profile) return <p className="py-20 text-center text-muted-foreground">User not found.</p>;

  const grid = tab === "posts" ? posts.filter((p) => p.kind === "post") : tab === "reels" ? posts.filter((p) => p.kind === "reel") : saved;
  const totalLikes = posts.reduce((n, p) => n + p.likes.length, 0);

  return (
    <div className="mx-auto max-w-3xl">
      <div className="relative h-28 overflow-hidden bg-neon opacity-80 sm:rounded-b-3xl"><div className="grid-bg absolute inset-0" /></div>
      <div className="-mt-12 px-4">
        <div className="flex items-end justify-between">
          <div className="rounded-full bg-background p-1"><Avatar src={profile.avatar_url} name={profile.username} size={96} ring /></div>
          {isMe ? (
            <button onClick={() => setEditing(true)} className="rounded-full border border-border bg-surface px-5 py-2 text-sm font-semibold hover:border-cyan">Edit profile</button>
          ) : (
            <div className="flex flex-wrap justify-end gap-2"><FollowButton targetId={profile.id} /><Link to="/messages" search={{ to: profile.id }} className="flex items-center gap-2 rounded-full bg-neon px-5 py-2 text-sm font-semibold text-primary-foreground glow-cyan">
              <MessageCircle className="h-4 w-4" /> Message
            </Link></div>
          )}
        </div>
        <h1 className="mt-3 flex items-center gap-2 font-display text-xl font-bold">{profile.display_name || profile.username}<VerifiedBadge userId={profile.id} /></h1>
        <p className="text-sm text-cyan">@{profile.username}</p>
        {profile.bio && <p className="mt-2 whitespace-pre-line text-sm">{profile.bio}</p>}
        <FollowCounts targetId={profile.id} />
        {isMe && <VerificationRequest />}
        <div className="mt-4 grid grid-cols-3 rounded-2xl border border-border bg-card py-3 text-center">
          <Stat n={posts.filter((p) => p.kind === "post").length} label="Posts" />
          <Stat n={posts.filter((p) => p.kind === "reel").length} label="Reels" />
          <Stat n={totalLikes} label="Likes" />
        </div>
      </div>

      <div className="mt-5 flex border-b border-border">
        {([["posts", Grid3x3], ["reels", Clapperboard], ...(isMe ? [["saved", Bookmark]] : [])] as [string, typeof Grid3x3][]).map(([k, Icon]) => (
          <button key={k} onClick={() => setTab(k as typeof tab)} className={cn("relative flex flex-1 justify-center py-3", tab === k ? "text-cyan" : "text-muted-foreground")} aria-label={k}>
            <Icon className="h-5 w-5" />
            {tab === k && <motion.span layoutId="tab" className="absolute inset-x-6 bottom-0 h-0.5 bg-neon" />}
          </button>
        ))}
      </div>
      <div className={cn("grid gap-0.5 p-0.5", tab === "reels" ? "grid-cols-3" : "grid-cols-3")}>
        {grid.map((p) => (
          <Button key={p.id} variant="ghost" onClick={() => setPreview(p)} aria-label={p.media_type === "video" ? "Open video preview" : "Open photo preview"} className={cn("group relative h-auto w-full overflow-hidden rounded-none bg-surface p-0", tab === "reels" ? "aspect-[9/16]" : "aspect-square")}>
            {p.media_type === "video" ? <video src={p.media_url} muted className="h-full w-full object-cover" /> : <img src={p.media_url} alt="" loading="lazy" className="h-full w-full object-cover" />}
            {p.media_type === "video" && <Play className="absolute right-2 top-2 h-4 w-4 fill-foreground" />}
            <div className="absolute inset-0 hidden items-center justify-center gap-3 bg-background/60 text-sm font-semibold group-hover:flex">
              <Heart className="h-4 w-4 fill-foreground" />{p.likes.length}
              <MessageCircle className="h-4 w-4 fill-foreground" />{p.comments[0]?.count ?? 0}
            </div>
          </Button>
        ))}
      </div>
      {grid.length === 0 && <p className="py-16 text-center text-sm text-muted-foreground">Nothing here yet.</p>}
      <MediaLightbox media={preview} onClose={() => setPreview(null)} />
      <AnimatePresence>{editing && <EditProfile profile={profile} onClose={() => setEditing(false)} />}</AnimatePresence>
    </div>
  );
}

function Stat({ n, label }: { n: number; label: string }) {
  return <div><p className="font-display text-lg font-bold">{n}</p><p className="text-xs text-muted-foreground">{label}</p></div>;
}

function EditProfile({ profile, onClose }: { profile: Profile; onClose: () => void }) {
  const [displayName, setDisplayName] = useState(profile.display_name ?? "");
  const [bio, setBio] = useState(profile.bio ?? "");
  const [avatar, setAvatar] = useState<File | null>(null);
  const [preview, setPreview] = useState(profile.avatar_url);
  const [busy, setBusy] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const qc = useQueryClient();

  async function save() {
    setBusy(true);
    try {
      const avatar_url = avatar ? (await uploadMedia(profile.id, avatar)).url : profile.avatar_url;
      const { error } = await supabase.from("profiles").update({ display_name: displayName.slice(0, 60), bio: bio.slice(0, 300), avatar_url }).eq("id", profile.id);
      if (error) throw error;
      qc.invalidateQueries();
      toast.success("Profile updated");
      onClose();
    } catch (e) { toast.error((e as Error).message); } finally { setBusy(false); }
  }

  const input = "w-full rounded-xl border border-input bg-surface px-4 py-3 text-sm outline-none focus:border-cyan";
  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 flex items-end justify-center bg-background/80 sm:items-center" onClick={onClose}>
      <motion.div initial={{ y: 60 }} animate={{ y: 0 }} exit={{ y: 60 }} onClick={(e) => e.stopPropagation()} className="w-full max-w-md rounded-t-3xl border border-border bg-card p-6 sm:rounded-3xl">
        <div className="mb-5 flex items-center justify-between">
          <h2 className="font-display text-lg font-bold">Edit profile</h2>
          <button onClick={onClose} aria-label="Close"><X className="h-5 w-5" /></button>
        </div>
        <button onClick={() => fileRef.current?.click()} className="mx-auto mb-5 flex flex-col items-center gap-2">
          <Avatar src={preview} name={profile.username} size={88} ring />
          <span className="text-sm font-semibold text-cyan">Change photo</span>
        </button>
        <input ref={fileRef} type="file" accept="image/*" hidden onChange={(e) => { const f = e.target.files?.[0]; if (f) { setAvatar(f); setPreview(URL.createObjectURL(f)); } }} />
        <div className="space-y-3">
          <input className={input} placeholder="Display name" value={displayName} onChange={(e) => setDisplayName(e.target.value)} maxLength={60} />
          <textarea className={cn(input, "h-24 resize-none")} placeholder="Bio" value={bio} onChange={(e) => setBio(e.target.value)} maxLength={300} />
        </div>
        <button onClick={save} disabled={busy} className="mt-5 w-full rounded-xl bg-neon py-3 font-semibold text-primary-foreground glow-cyan">
          {busy ? <Loader2 className="mx-auto h-5 w-5 animate-spin" /> : "Save"}
        </button>
      </motion.div>
    </motion.div>
  );
}
