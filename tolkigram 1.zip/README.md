# Talkigram

Create a full-stack, mobile-first Instagram alternative web app with a unique modern dark-neon UI.

Include all core features:

1. Stories & History: Top horizontal story bar with interactive full-screen story viewer, progress bars, and reply box.

2. Posts Feed: Photo and video feed with double-tap to like animation, interactive comments section, like counter, and save post feature.

3. Vertical Reels Player: Full-screen short video player with seamless vertical scrolling, sound toggle, and like/comment buttons.

4. Direct Messaging (Chat): Full real-time messaging UI with contact list, chat window, media sharing preview, and online indicators.

5. Explore & Search Grid: Responsive masonry feed for trending posts, creators, and hashtags search.

6. User Profile: Custom bio, profile picture, post grid, reels tab, and edit profile modal.

7. Post Creation Modal: Multi-step media uploader for posts and reels with preview and caption input.

Tech Stack:

- React (Vite), Tailwind CSS, Lucide Icons, and Framer Motion for smooth transitions.

- Fully integrated with Supabase for Database, User Authentication (Signup/Login), and File Storage.

- Distinct non-Instagram visual design using dark zinc background with electric violet and cyan neon accents.

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://talkigram.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/93207aa9-ea61-43a6-bbe0-373b544f5f35).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
